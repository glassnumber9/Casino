<?php
$pdo = new PDO('mysql:host=localhost;dbname=casino;charset=utf8mb4', 'me', '1234', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

